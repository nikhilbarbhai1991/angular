import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { RootComponent } from "./root.component";
import { FormsModule } from "@angular/forms";
import { ListComponent } from "./ListComponent/list.component";
import { CommonModule } from "@angular/common";

@NgModule({
    imports: [BrowserModule, CommonModule, FormsModule],
    declarations: [RootComponent, ListComponent],
    bootstrap: [RootComponent]
})
export class AppModule{

}