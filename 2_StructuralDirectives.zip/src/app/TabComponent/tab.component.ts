import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-tab',
    template: `
        <div>
            <ng-content></ng-content>
        </div>
    `
})

export class TabComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}