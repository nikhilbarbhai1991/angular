import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'tab-root',
    template: `
        <div>
            <app-tab>Tab 1</app-tab>
        </div>
    `
})

export class NameComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}