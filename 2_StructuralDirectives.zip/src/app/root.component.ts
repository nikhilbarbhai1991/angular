import { Component } from "@angular/core";

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <!-- <h3 *ngIf="message; else elseBlock">{{message}}</h3>
            <ng-template #elseBlock>
                <h3>Nothing to Display</h3>
            </ng-template> -->

            <!-- <list></list> -->
            <ul [ngSwitch]="person">
                <li *ngSwitchCase="'Manish'">Hello Manish</li>
                <li *ngSwitchCase="'Abhijeet'">Hello Abhijeet</li>
                <li *ngSwitchCase="'RK'">Hello Ram</li>
            </ul>
        </div>
    `
})
export class RootComponent {
    message: string;
    person: string;

    constructor() {
        this.message = "Hello World!";
        this.person = "RK"
    }
}