import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'assign1',
    template: `<select [(ngModel)]=selected>
        <option value="Item1">Item One</option>
        <option value="Item2">Item Two</option>
        <option value="Item3">Item Three</option>
    </select>
    <br/>
    <h3>Selected: {{selected}}</h3>`
})

export class Assign1Component implements OnInit {
    constructor() { }

    ngOnInit() { }
}