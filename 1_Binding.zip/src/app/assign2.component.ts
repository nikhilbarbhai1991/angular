import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'assign2',
    template: `
        <textarea readonly>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illo, fugiat? Enim quasi animi quis porro minus quaerat ratione iusto quibusdam temporibus pariatur obcaecati, molestias sequi consequuntur ab. Consectetur, consequuntur ut.</textarea>
        <input type="checkbox" [(ngModel)]=flag> Agree Terms<br><br>
        <button class="btn btn-primary btn-block" [disabled]=!flag>Next</button>
        `,
    styles: [`
        textarea {
            height: 75px;
            width: 100%;
            resize: none;
        }
    `]
})

export class Assign2Component implements OnInit {
    constructor() { }

    ngOnInit() { }
}