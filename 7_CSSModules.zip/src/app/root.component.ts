import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'root',
    template: ` <div class="container">
        <h2 class="text-danger">Root Component Loaded..</h2>
        <cone>COne Loading...</cone>
        <ctwo>CTwo Loading...</ctwo>
    </div>`
})

export class RootComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}