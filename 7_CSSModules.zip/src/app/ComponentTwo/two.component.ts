import { Component } from "@angular/core";

var styles = require('./two.component.css');

@Component({
    selector: 'ctwo',
    template: `
        <h2 class="text-success">Hello from Component Two!</h2>
        <h3 class="${styles.card}">Just for Check</h3>
        `
})
export class ComponentTwo { }