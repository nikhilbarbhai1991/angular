import { Component } from "@angular/core";

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <rf></rf>
            <!-- <tf></tf> -->
            <!-- <mb></mb> -->
        </div>
    `
})
export class RootComponent {
    constructor() {
    }
}