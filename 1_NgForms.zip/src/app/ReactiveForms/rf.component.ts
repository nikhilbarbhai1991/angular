// 3. --------------------------------------------------- Using FormBuilder & DI & Validation
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
    selector: 'rf',
    templateUrl: 'rf.component.html'
})

export class ReactiveFormsComponent implements OnInit {
    rForm: FormGroup;

    constructor(private fb: FormBuilder) { }

    ngOnInit() {
        this.rForm = this.fb.group({
            firstname: [null, Validators.required],
            lastname: [null, Validators.compose([Validators.required,
            Validators.minLength(2), Validators.maxLength(20)])],
            address: this.fb.group({
                city: [null, Validators.required],
                zip: 0
            })
        })
    }

    logForm(frm: FormGroup) {
        if (frm.valid) {
            // Code to send data to API
            console.log(frm);
        } else
            console.error("Invalid Form")
    }
}

// //2. --------------------------------------------------- Using FormBuilder & DI
// import { Component, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';

// @Component({
//     selector: 'rf',
//     templateUrl: 'rf.component.html'
// })

// export class ReactiveFormsComponent implements OnInit {
//     rForm: FormGroup;

//     constructor(private fb: FormBuilder) { }

//     ngOnInit() {
//         this.rForm = this.fb.group({
//             firstname: "Manish",
//             lastname: "",
//             address: this.fb.group({
//                 city: "",
//                 zip: 0
//             })
//         })
//     }

//     logForm(frm: FormGroup) {
//         console.log(frm);
//     }
// }

// //1. --------------------------------------------------- Using FormGroup, FormControl 
// import { Component, OnInit } from '@angular/core';
// import { FormGroup, FormControl } from '@angular/forms';

// @Component({
//     selector: 'rf',
//     templateUrl: 'rf.component.html'
// })

// export class ReactiveFormsComponent implements OnInit {
//     rForm: FormGroup;

//     constructor() { }

//     ngOnInit() {
//         this.rForm = new FormGroup({
//             firstname: new FormControl(),
//             lastname: new FormControl(),
//             address: new FormGroup({
//                 city: new FormControl(),
//                 zip: new FormControl()
//             })
//         })
//     }

//     logForm(frm: FormGroup) {
//         console.log(frm);
//     }
// }